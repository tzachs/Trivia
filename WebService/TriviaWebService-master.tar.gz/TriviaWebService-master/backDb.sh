mysqldump triviadb -uroot -pbella@123! -r backup.sql
